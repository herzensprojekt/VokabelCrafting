/* =====================================================================
   LingoCrafter - Service Worker

   Zwei Aufgaben:

   1) Ohne einen Service Worker bietet Chrome auf Android gar keinen
      Installations-Dialog an (das Ereignis "beforeinstallprompt" bleibt
      sonst aus). Er ist also die Voraussetzung dafuer, dass der Knopf
      "Jetzt installieren" ueberhaupt erscheinen kann.

   2) Er macht die App offline benutzbar - im Zug, im Ferienhaus, im
      Funkloch.

   WICHTIG - Strategie: Fuer die Seite selbst NETZ ZUERST, fuer Bilder
   ZWISCHENSPEICHER ZUERST.

   Der Grund: An LingoCrafter wird oft etwas geaendert. Wuerde die Seite aus
   dem Zwischenspeicher kommen, sitzen Kinder wochenlang auf einer alten
   Fassung und melden Fehler, die laengst behoben sind. Deshalb wird die
   Seite immer frisch geholt, wenn Netz da ist - und nur bei fehlendem Netz
   aus dem Speicher. Die Bilder aendern sich dagegen fast nie und duerfen
   sofort aus dem Speicher kommen.

   ---------------------------------------------------------------------
   FEHLER, DER LANGE UNBEMERKT BLIEB (behoben in v3):

   "Netz zuerst" war ein Irrtum. Ein schlichtes fetch() aus dem Service
   Worker fragt ZUERST den HTTP-Zwischenspeicher des Browsers - und
   GitHub Pages liefert die Seite mit "Cache-Control: max-age=600".
   Zehn Minuten lang bekam der Service Worker also die ALTE Seite, gab
   sie aus UND schrieb sie sich erneut in seinen eigenen Speicher.

   Am laufenden Browser gemessen, unmittelbar nach einem Upload:
       fetch("./")                    -> 7ddebf02   (alte Fassung)
       fetch("./", {cache:"reload"})  -> b516c5bb   (neue Fassung)

   Genau daher kamen die Faelle "ich habe hochgeladen, aber es hat sich
   nichts geaendert". Fuer die Seite wird der HTTP-Zwischenspeicher jetzt
   ausdruecklich uebergangen.
===================================================================== */

/* v4: Die Symbole wurden ausgetauscht, ohne die Dateinamen zu
   aendern. Ein neuer Speichername ist der einzige Weg, die alten
   Bilder loszuwerden - der activate-Haken unten raeumt jeden Speicher
   weg, der nicht so heisst. */
/* v5: Die Symbole wurden noch einmal neu gerechnet (Freistellung,
   Groesse) und logo.png durch vorschau.png ersetzt. Wieder gleiche
   Dateinamen, also wieder ein neuer Speichername - sonst kaeme beim
   ersten Oeffnen noch die Fassung von v90.3. */
/* v6: zweiter Satz Symbole, wieder unter denselben Dateinamen. */
/* v7: DIE LISTE WAR ZU KURZ - und das war der Offline-Fehler.

   Am laufenden Browser nachgesehen, nach einem normalen Besuch: neun
   Dateien im Speicher, vierzehn fehlten - darunter JEDES Symbol und
   das grosse Lingora-Bild. Bilder kommen zwar "Zwischenspeicher
   zuerst", landen dort aber erst, nachdem sie einmal geladen wurden.
   Und die meisten tragen loading="lazy": Wer nie zu ihnen gescrollt
   ist, hat sie nie geladen. Ohne Netz war die App damit eine Seite
   voller leerer Rahmen.

   Jetzt steht hier alles drin, was die App zum Anzeigen braucht.
   Nicht dabei: logo.png (wird nirgends mehr aufgerufen) und
   vorschau.png (nur das Bild fuer geteilte Links, nie im Bild). */
/* v9: Der Service Worker beantwortet jetzt Fragen der Seite
   ("offline-pruefen", "offline-fuellen"). Ein neuer Speichername
   ist nicht noetig - die Dateien sind dieselben -, aber ein neuer
   Service Worker schon, und den erkennt der Browser an jeder
   Aenderung in dieser Datei. */
/* v8: ic-karten.webp ist dazugekommen. Ein neuer Speichername ist
   der Weg, die Liste von v7 loszuwerden - sonst fehlte das neue
   Symbol genau denen, die schon offline gespeichert haben. */
/* v10: Zehn Symbole und Lingora neu gezeichnet (Buntstift), wieder
   unter denselben Dateinamen - also wieder ein neuer Speichername,
   sonst saehe man offline noch die alten Bilder. */
const CACHE = "lingocrafter-v10";
const MITNEHMEN = [
  "./",
  "./index.html",
  "./manifest.json",
  "./ic-avatar.webp",
  "./ic-buch.webp",
  "./ic-eigene.webp",
  "./ic-geschenk.webp",
  "./ic-grammatik.webp",
  "./ic-herz.webp",
  "./ic-karten.webp",
  "./ic-muenzen.webp",
  "./ic-plan.webp",
  "./ic-rangliste.webp",
  "./ic-skills.webp",
  "./ic-speicher.webp",
  "./ic-spiele.webp",
  "./icon-192.png",
  "./icon-512.png",
  "./lingora-gross.webp",
  "./lingora.webp",
  "./logo-emblem.webp",
  "./titelbild.webp",
  "./logo.png",
  "./logo-neu.webp"
];

/* Holt etwas unter Umgehung des HTTP-Zwischenspeichers. Faellt auf den
   gewoehnlichen Weg zurueck, falls ein Browser "reload" nicht mag -
   lieber eine alte Seite als gar keine. */
function frischHolen(url){
  return fetch(url, {cache: "reload", credentials: "same-origin"})
           .catch(()=> fetch(url));
}

self.addEventListener("install", (e)=>{
  e.waitUntil(
    caches.open(CACHE)
      .then(c => Promise.all(MITNEHMEN.map(u =>
        frischHolen(u).then(a => a && a.ok ? c.put(u, a) : null).catch(()=>{})
      )))
      .then(()=> self.skipWaiting())
  );
});

self.addEventListener("activate", (e)=>{
  e.waitUntil(
    caches.keys()
      .then(namen => Promise.all(namen.filter(n => n !== CACHE).map(n => caches.delete(n))))
      /* Und den alten Muell aus dem eigenen Speicher: die
         version.json-Eintraege mit Zeitstempel, die sich dort ueber
         Monate angesammelt haben. */
      .then(()=> caches.open(CACHE))
      .then(c => c.keys().then(alle => Promise.all(
        alle.filter(r => r.url.indexOf("version.json") >= 0).map(r => c.delete(r)))))
      .then(()=> self.clients.claim())
  );
});

/* =====================================================================
   AUSKUNFT UND AUFTRAG

   Die Seite soll zeigen koennen, ob LingoCrafter wirklich offline
   bereit ist - und es auf Knopfdruck herstellen. Dafuer fragt sie
   NICHT selbst den Zwischenspeicher ab.

   Der Grund: Die Dateiliste MITNEHMEN und der Name des Speichers
   stehen hier. Haette die Seite ihre eigene Liste, waeren es zwei -
   und die eine wuerde irgendwann vergessen, wenn ein Bild dazukommt.
   Sie meldete dann "fertig", und offline fehlte trotzdem etwas.

   Geantwortet wird ueber den Port, den die Seite mitschickt
   (MessageChannel). Dadurch bekommt genau das fragende Fenster die
   Antwort - und nicht alle offenen gleichzeitig.
===================================================================== */
self.addEventListener("message", (e)=>{
  const auftrag = (e.data || {}).lc;
  const sagen = (o)=>{ try{ if(e.ports && e.ports[0]) e.ports[0].postMessage(o); }catch(x){} };

  if(auftrag === "offline-pruefen"){
    e.waitUntil((async ()=>{
      try{
        const c = await caches.open(CACHE);
        const da = await Promise.all(MITNEHMEN.map(u => c.match(u).then(t => !!t)));
        sagen({ lc:"stand", da: da.filter(Boolean).length, gesamt: MITNEHMEN.length });
      }catch(x){
        sagen({ lc:"stand", da: 0, gesamt: MITNEHMEN.length });
      }
    })());
    return;
  }

  if(auftrag === "offline-fuellen"){
    e.waitUntil((async ()=>{
      const c = await caches.open(CACHE);
      let fertig = 0, bytes = 0;
      const fehlen = [];
      for(const u of MITNEHMEN){
        try{
          const a = await frischHolen(u);
          if(a && a.ok){
            /* Erst den Zwilling wegschreiben, dann den Koerper lesen -
               ein Response laesst sich nur EINMAL auslesen. */
            const kopie = a.clone();
            await c.put(u, kopie);
            bytes += (await a.blob()).size;
          } else {
            fehlen.push(u);
          }
        }catch(x){ fehlen.push(u); }
        fertig++;
        sagen({ lc:"fortschritt", fertig: fertig, gesamt: MITNEHMEN.length });
      }
      sagen({ lc:"fertig", da: MITNEHMEN.length - fehlen.length,
              gesamt: MITNEHMEN.length, bytes: bytes, fehlen: fehlen });
    })());
    return;
  }
});

self.addEventListener("fetch", (e)=>{
  const anfrage = e.request;
  if(anfrage.method !== "GET") return;

  const url = new URL(anfrage.url);
  if(url.origin !== self.location.origin) return;      // Firebase & Co. nie anfassen

  /* version.json ist die Frage "gibt es etwas Neues?" und haengt dafuer
     einen Zeitstempel an. Fuer den Service Worker sah jede dieser
     Adressen wie eine eigene Datei aus - er speicherte sie und las sie
     nie wieder. Gemessen: vier solcher Leichen bei dreizehn
     Eintraegen. Hier wird sie durchgereicht und nicht angefasst. */
  if(url.pathname.endsWith("version.json")) return;

  const istSeite = anfrage.mode === "navigate" ||
                   url.pathname.endsWith("/") ||
                   url.pathname.endsWith("index.html");

  if(istSeite){
    // Netz zuerst - und zwar WIRKLICH das Netz, nicht der
    // HTTP-Zwischenspeicher des Browsers.
    e.respondWith(
      frischHolen(anfrage.url)
        .then(antwort => {
          if(!antwort || !antwort.ok) throw new Error("nicht ok");
          const kopie = antwort.clone();
          caches.open(CACHE).then(c => c.put(anfrage, kopie)).catch(()=>{});
          return antwort;
        })
        .catch(()=> caches.match(anfrage).then(t => t || caches.match("./index.html")))
    );
    return;
  }

  /* Bilder und Manifest: Zwischenspeicher zuerst, im Hintergrund
     auffrischen.

     Die Auffrischung geht ueber frischHolen und damit am
     HTTP-Zwischenspeicher vorbei. Mit einem schlichten fetch() haette
     GitHub Pages ("Cache-Control: max-age=600") bis zu zehn Minuten
     lang die alten Bytes geliefert - und der Service Worker haette sie
     sich brav erneut eingespeichert. Derselbe Fehler wie oben bei der
     Seite, nur eine Zeile tiefer. */
  e.respondWith(
    caches.match(anfrage).then(treffer => {
      const ausDemNetz = frischHolen(anfrage.url).then(antwort => {
        const kopie = antwort.clone();
        caches.open(CACHE).then(c => c.put(anfrage, kopie)).catch(()=>{});
        return antwort;
      }).catch(()=> treffer);
      return treffer || ausDemNetz;
    })
  );
});
